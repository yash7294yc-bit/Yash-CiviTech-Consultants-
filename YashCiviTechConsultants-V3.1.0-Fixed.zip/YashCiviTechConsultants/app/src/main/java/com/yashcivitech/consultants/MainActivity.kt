package com.yashcivitech.consultants

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import coil.compose.AsyncImage
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val DeepGreen = Color(0xFF06261F)
private val Gold = Color(0xFFD9B86C)
private val Ivory = Color(0xFFF7F1E4)
private val SoftGreen = Color(0xFFE8F0EC)
private const val REMOTE_CONTENT = "https://raw.githubusercontent.com/yash7294yc-bit/Yash-CiviTech-Consultants/main/content.json"

data class Category(val name: String, val icon: String, val description: String, val overview: String, val topics: String, val workflow: String, val standards: String, val sourceUrl: String, val detailedContent: String, val references: String, val image: String)
data class Research(val title: String, val tag: String, val summary: String, val source: String, val url: String)
data class Practical(val title: String, val group: String, val objective: String, val standards: String, val equipment: String, val procedure: String, val calculation: String, val interpretation: String, val precautions: String, val sourceUrl: String)
data class Standard(val code: String, val title: String, val status: String, val scope: String, val notes: String, val url: String)
data class Tool(val title: String, val formula: String, val note: String, val details: String)
data class Template(val title: String, val fields: List<String>)
data class Media(val title: String, val type: String, val url: String)
data class Content(val categories: List<Category>, val research: List<Research>, val practicals: List<Practical>, val standards: List<Standard>, val tools: List<Tool>, val templates: List<Template>, val media: List<Media>)
data class Detail(val title: String, val subtitle: String, val body: String, val url: String? = null, val image: String? = null)

enum class Tab { HOME, LEARN, RESEARCH, FIELD, MORE }

class MainActivity : ComponentActivity() {
    private var contentState = mutableStateOf(emptyContent())
    private var onlineState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        contentState.value = runCatching {
            assets.open("content.json").bufferedReader().use { parseContent(it.readText()) }
        }.getOrElse { emptyContent() }

        setContent {
            val colors = lightColorScheme(
                primary = DeepGreen,
                secondary = Gold,
                background = Ivory,
                surface = Color.White,
                onPrimary = Color.White,
                onBackground = DeepGreen,
                onSurface = DeepGreen
            )
            MaterialTheme(colorScheme = colors) {
                AppRoot(contentState.value, onlineState.value)
            }
        }

        lifecycleScope.launch {
            val remote = loadRemoteContent()
            if (remote != null) {
                contentState.value = remote
                onlineState.value = true
            }
        }
    }

    private suspend fun loadRemoteContent(): Content? = withContext(Dispatchers.IO) {
        runCatching {
            val connection = URL(REMOTE_CONTENT).openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.requestMethod = "GET"
            try {
                connection.inputStream.bufferedReader().use { parseContent(it.readText()) }
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot(content: Content, online: Boolean) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var search by remember { mutableStateOf("") }

    if (detail != null) {
        DetailScreen(detail = detail!!, back = { detail = null })
        return
    }

    Scaffold(
        containerColor = Ivory,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("YASH CIVITECH", fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("CONSULTANTS - V3.0", style = MaterialTheme.typography.labelSmall, color = Gold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepGreen),
                actions = {
                    IconButton(onClick = { tab = Tab.LEARN }) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, modifier = Modifier.navigationBarsPadding()) {
                NavigationBarItem(selected = tab == Tab.HOME, onClick = { tab = Tab.HOME }, icon = { Icon(Icons.Default.Home, "Home") }, label = { Text("Home") })
                NavigationBarItem(selected = tab == Tab.LEARN, onClick = { tab = Tab.LEARN }, icon = { Icon(Icons.Default.MenuBook, "Learn") }, label = { Text("Learn") })
                NavigationBarItem(selected = tab == Tab.RESEARCH, onClick = { tab = Tab.RESEARCH }, icon = { Icon(Icons.Default.Science, "Research") }, label = { Text("Research") })
                NavigationBarItem(selected = tab == Tab.FIELD, onClick = { tab = Tab.FIELD }, icon = { Icon(Icons.Default.Work, "Field") }, label = { Text("Field") })
                NavigationBarItem(selected = tab == Tab.MORE, onClick = { tab = Tab.MORE }, icon = { Icon(Icons.Default.CollectionsBookmark, "More") }, label = { Text("More") })
            }
        }
    ) { padding ->
        when (tab) {
            Tab.HOME -> HomeScreen(content, online, padding) { detail = it }
            Tab.LEARN -> LearnScreen(content, padding, search, { search = it }) { detail = it }
            Tab.RESEARCH -> ResearchScreen(content, padding) { detail = it }
            Tab.FIELD -> FieldScreen(content, padding) { detail = it }
            Tab.MORE -> MoreScreen(content, padding) { detail = it }
        }
    }
}

@Composable
private fun HomeScreen(content: Content, online: Boolean, padding: PaddingValues, open: (Detail) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = DeepGreen), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp)) {
                Text("CIVIL ENGINEERING KNOWLEDGE BASE", color = Gold, fontWeight = FontWeight.Bold)
                Text("Learn. Build. Research. Verify.", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("Detailed core knowledge, BIS/IS references, field and laboratory practicals, tools, templates and research.", color = Ivory)
                Spacer(Modifier.height(12.dp))
                Text(if (online) "LIVE LIBRARY CONNECTED" else "OFFLINE LIBRARY READY", color = Gold, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(18.dp))
        SectionTitle("Core knowledge", "Civil engineering domains")
        Spacer(Modifier.height(10.dp))
        content.categories.take(8).forEach { category ->
            CategoryCard(category) { open(categoryDetail(category)) }
            Spacer(Modifier.height(10.dp))
        }
        SectionTitle("Latest research", "Evidence-linked learning")
        Spacer(Modifier.height(10.dp))
        content.research.take(4).forEach { research ->
            ResearchCard(research) { open(researchDetail(research)) }
            Spacer(Modifier.height(10.dp))
        }
        SectionTitle("Standards index", "BIS / IS references")
        Spacer(Modifier.height(10.dp))
        content.standards.take(4).forEach { standard ->
            StandardCard(standard) { open(standardDetail(standard)) }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun LearnScreen(content: Content, padding: PaddingValues, search: String, onSearch: (String) -> Unit, open: (Detail) -> Unit) {
    val filtered = content.categories.filter {
        it.name.contains(search, true) || it.description.contains(search, true) || it.topics.contains(search, true)
    }
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text("Search civil engineering") })
        Spacer(Modifier.height(14.dp))
        Text("Knowledge Library", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text("Fundamentals, workflow, standards guidance and applications", color = Color.Gray)
        Spacer(Modifier.height(10.dp))
        filtered.forEach { category ->
            CategoryCard(category) { open(categoryDetail(category)) }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(70.dp))
    }
}

@Composable
private fun ResearchScreen(content: Content, padding: PaddingValues, open: (Detail) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(16.dp))
        Text("Research & Trends", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text("Research summaries with source links", color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        content.research.forEach { research ->
            ResearchCard(research) { open(researchDetail(research)) }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun FieldScreen(content: Content, padding: PaddingValues, open: (Detail) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(16.dp))
        Text("Field & Laboratory", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text("Purpose -> standard -> equipment -> procedure -> calculation -> interpretation -> precautions", color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        content.practicals.forEach { practical ->
            PracticalCard(practical) { open(practicalDetail(practical)) }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun MoreScreen(content: Content, padding: PaddingValues, open: (Detail) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(16.dp))
        Text("Professional Toolkit", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(14.dp))
        SectionTitle("BIS / IS Standards", "Indexed references")
        Spacer(Modifier.height(10.dp))
        content.standards.forEach { standard ->
            StandardCard(standard) { open(standardDetail(standard)) }
            Spacer(Modifier.height(10.dp))
        }
        SectionTitle("Engineering tools", "Educational formulas")
        Spacer(Modifier.height(10.dp))
        content.tools.forEach { tool ->
            ToolCard(tool) { open(Detail(tool.title, "Formula / calculator", "${tool.formula}\n\n${tool.note}\n\nDetails: ${tool.details}")) }
            Spacer(Modifier.height(10.dp))
        }
        SectionTitle("Site templates", "Ready-to-customize formats")
        Spacer(Modifier.height(10.dp))
        content.templates.forEach { template ->
            val tool = Tool(template.title, "Template", template.fields.joinToString(" - "), "Field checklist")
            ToolCard(tool) { open(Detail(template.title, "Template", template.fields.joinToString("\n- "))) }
            Spacer(Modifier.height(10.dp))
        }
        SectionTitle("Media Hub", "External learning resources")
        Spacer(Modifier.height(10.dp))
        content.media.forEach { media ->
            MediaCard(media)
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(80.dp))
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
        }
        Text("*", color = Gold, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CategoryCard(category: Category, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (category.image.isNotBlank()) {
                AsyncImage(model = "file:///android_asset/${category.image}", contentDescription = category.name, modifier = Modifier.size(72.dp))
            } else {
                Text(category.icon, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.size(44.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(category.name, fontWeight = FontWeight.Bold)
                Text(category.description, maxLines = 3, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun ResearchCard(research: Research, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = SoftGreen)) {
        Column(Modifier.padding(16.dp)) {
            Text(research.tag, color = DeepGreen, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
            Text(research.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(5.dp))
            Text(research.summary, color = Color.DarkGray, maxLines = 4, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PracticalCard(practical: Practical, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Science, null, tint = DeepGreen, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(practical.title, fontWeight = FontWeight.Bold)
                Text(practical.group, color = Gold, style = MaterialTheme.typography.labelMedium)
                Text(practical.objective, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun StandardCard(standard: Standard, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(standard.code, color = DeepGreen, fontWeight = FontWeight.ExtraBold)
            Text(standard.title, fontWeight = FontWeight.Bold)
            Text(standard.status, color = Gold, style = MaterialTheme.typography.labelSmall)
            Text(standard.scope, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ToolCard(tool: Tool, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            val icon = if (tool.formula == "Template") Icons.Default.CollectionsBookmark else Icons.Default.Calculate
            Icon(icon, null, tint = DeepGreen, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(tool.title, fontWeight = FontWeight.Bold)
                Text(tool.formula, color = DeepGreen)
                Text(tool.note, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun MediaCard(media: Media) {
    val context = LocalContext.current
    Card(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(media.url))) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.PlayCircleOutline, null, tint = DeepGreen, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(12.dp))
            Text(media.title, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailScreen(detail: Detail, back: () -> Unit) {
    val context = LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(detail.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = back) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepGreen, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp).verticalScroll(rememberScrollState())) {
            Text(detail.subtitle, color = Gold, fontWeight = FontWeight.Bold)
            if (!detail.image.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                AsyncImage(model = "file:///android_asset/${detail.image}", contentDescription = detail.title, modifier = Modifier.fillMaxWidth().height(190.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(detail.body, style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(22.dp))
            if (detail.url != null) {
                Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(detail.url))) }, colors = ButtonDefaults.buttonColors(containerColor = DeepGreen), modifier = Modifier.fillMaxWidth()) {
                    Text("Open official/source reference", color = Color.White)
                }
            }
        }
    }
}

private fun categoryDetail(category: Category): Detail = Detail(
    category.name,
    "Detailed core knowledge • topic-wise learning",
    "${category.detailedContent}\n\nKEY TOPICS\n${category.topics}\n\nENGINEERING WORKFLOW\n${category.workflow}\n\nSTANDARDS / VERIFICATION\n${category.standards}\n\nLEARNING REFERENCES\n${category.references}",
    category.sourceUrl,
    category.image
)

private fun researchDetail(research: Research): Detail = Detail(
    research.title,
    research.tag,
    "${research.summary}\n\nSource: ${research.source}",
    research.url
)

private fun practicalDetail(practical: Practical): Detail = Detail(
    practical.title,
    practical.group,
    "OBJECTIVE\n${practical.objective}\n\nSTANDARD / REFERENCE\n${practical.standards}\n\nEQUIPMENT\n${practical.equipment}\n\nPROCEDURE\n${practical.procedure}\n\nCALCULATION\n${practical.calculation}\n\nINTERPRETATION\n${practical.interpretation}\n\nPRECAUTIONS\n${practical.precautions}",
    practical.sourceUrl
)

private fun standardDetail(standard: Standard): Detail = Detail(
    standard.code,
    standard.title,
    "STATUS\n${standard.status}\n\nSCOPE\n${standard.scope}\n\nAPP GUIDANCE\n${standard.notes}\n\nThe app provides an original educational summary and reference metadata; it does not reproduce the copyrighted standard text.",
    standard.url
)

private fun emptyContent(): Content = Content(emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList())

private fun parseContent(text: String): Content {
    val root = JSONObject(text)
    val categories = mutableListOf<Category>()
    val categoryArray = root.getJSONArray("categories")
    for (i in 0 until categoryArray.length()) {
        val item = categoryArray.getJSONObject(i)
        categories.add(Category(item.getString("name"), item.getString("icon"), item.getString("description"), item.getString("overview"), item.getString("key_topics"), item.getString("engineering_workflow"), item.getString("standards_guidance"), item.getString("source_url"), item.optString("detailed_content", item.getString("overview")), item.optString("references", item.getString("standards_guidance")), item.optString("image", "")))
    }

    val research = mutableListOf<Research>()
    val researchArray = root.getJSONArray("research")
    for (i in 0 until researchArray.length()) {
        val item = researchArray.getJSONObject(i)
        research.add(Research(item.getString("title"), item.getString("tag"), item.getString("summary"), item.getString("source"), item.getString("url")))
    }

    val practicals = mutableListOf<Practical>()
    val practicalArray = root.getJSONArray("practicals")
    for (i in 0 until practicalArray.length()) {
        val item = practicalArray.getJSONObject(i)
        practicals.add(Practical(item.getString("title"), item.getString("group"), item.getString("objective"), item.getString("standards"), item.getString("equipment"), item.getString("procedure"), item.getString("calculation"), item.getString("interpretation"), item.getString("precautions"), item.getString("source_url")))
    }

    val standards = mutableListOf<Standard>()
    val standardArray = root.getJSONArray("standards")
    for (i in 0 until standardArray.length()) {
        val item = standardArray.getJSONObject(i)
        standards.add(Standard(item.getString("code"), item.getString("title"), item.getString("status"), item.getString("scope"), item.getString("notes"), item.getString("url")))
    }

    val tools = mutableListOf<Tool>()
    val toolArray = root.getJSONArray("tools")
    for (i in 0 until toolArray.length()) {
        val item = toolArray.getJSONObject(i)
        tools.add(Tool(item.getString("title"), item.getString("formula"), item.getString("note"), item.getString("details")))
    }

    val templates = mutableListOf<Template>()
    val templateArray = root.getJSONArray("templates")
    for (i in 0 until templateArray.length()) {
        val item = templateArray.getJSONObject(i)
        val fields = mutableListOf<String>()
        val fieldArray = item.getJSONArray("fields")
        for (j in 0 until fieldArray.length()) fields.add(fieldArray.getString(j))
        templates.add(Template(item.getString("title"), fields))
    }

    val media = mutableListOf<Media>()
    val mediaArray = root.getJSONArray("media")
    for (i in 0 until mediaArray.length()) {
        val item = mediaArray.getJSONObject(i)
        media.add(Media(item.getString("title"), item.getString("type"), item.getString("url")))
    }

    return Content(categories, research, practicals, standards, tools, templates, media)
}
