# Yash CiviTech Consultants — V2.0

A luxury civil-engineering knowledge and professional toolkit app.

## V2 highlights
- 24 civil-engineering domains
- Offline bundled core library with online JSON refresh
- Research & trending technology hub
- Field/lab practical test library
- Engineering formulas and tool cards
- Site templates: method statement, ITP, DPR, concrete pour, rebar, safety, RFI/WIR, BOQ
- Video learning hub
- Search and detail views
- Same package name and release signing configuration as V1

## Updating content without rebuilding the APK
Edit `app/src/main/assets/content.json` and publish the same JSON at the GitHub `main` branch root as `content.json`. The app checks the raw GitHub file at startup and falls back to the bundled copy when offline.

Remote URL used by the app:
`https://raw.githubusercontent.com/yash7294yc-bit/Yash-CiviTech-Consultants/main/content.json`

## Release
Version code: 2
Version name: 2.0.0
Application ID: `com.yashcivitech.consultants`

The GitHub Actions workflow builds a signed APK and AAB using the existing release secrets.


## V3.1 content upgrade
This release contains detailed, original, topic-wise civil engineering explanations for all 24 core domains, bundled educational diagrams, practicals, standards references, research links, and open-learning resources. It does not reproduce copyrighted textbook or BIS/IS text.
