package com.yashcivitech.consultants

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val DeepGreen = Color(0xFF06261F)
private val Gold = Color(0xFFD9B86C)
private val Ivory = Color(0xFFF7F1E4)
private val SoftGreen = Color(0xFFE8F0EC)
private const val REMOTE_CONTENT = "https://raw.githubusercontent.com/yash7294yc-bit/Yash-CiviTech-Consultants/main/content.json"

data class Category(val name: String, val icon: String, val description: String)
data class Research(val title: String, val tag: String, val summary: String, val source: String, val url: String)
data class Practical(val title: String, val group: String, val purpose: String, val steps: String)
data class Tool(val title: String, val formula: String, val note: String)
data class Template(val title: String, val fields: String)
data class Media(val title: String, val type: String, val url: String)
data class Content(val categories: List<Category>, val research: List<Research>, val practicals: List<Practical>, val tools: List<Tool>, val templates: List<Template>, val media: List<Media>)

enum class Tab { HOME, LEARN, RESEARCH, FIELD, MORE }

enum class DetailType { CATEGORY, RESEARCH, PRACTICAL, TOOL, TEMPLATE }

data class Detail(val type: DetailType, val title: String, val subtitle: String, val body: String, val url: String? = null)

class MainActivity : ComponentActivity() {
    private var contentState = mutableStateOf(Content(emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList()))
    private var onlineState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Load the bundled V2 library first. This guarantees content is available even without internet.
        contentState.value = runCatching { assets.open("content.json").bufferedReader().use { parseContent(it.readText()) } }
            .getOrElse { sampleContent() }
        setContent {
            MaterialTheme(
                colorScheme = androidx.compose.material3.lightColorScheme(
                    primary = DeepGreen,
                    secondary = Gold,
                    background = Ivory,
                    surface = Color.White,
                    onPrimary = Color.White,
                    onBackground = DeepGreen,
                    onSurface = DeepGreen
                )
            ) {
                AppRoot(contentState.value, onlineState.value)
            }
        }
        lifecycleScope.launch {
            val remote = loadRemoteContent()
            if (remote != null) {
                contentState.value = remote
                onlineState.value = true
            }
        }
    }

    private suspend fun loadRemoteContent(): Content? = withContext(Dispatchers.IO) {
        runCatching {
            val connection = URL(REMOTE_CONTENT).openConnection() as HttpURLConnection
            connection.connectTimeout = 7000
            connection.readTimeout = 7000
            connection.requestMethod = "GET"
            connection.inputStream.bufferedReader().use { parseContent(it.readText()) }
                .also { connection.disconnect() }
        }.getOrNull()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.compose.runtime.Composable
private fun AppRoot(content: Content, online: Boolean) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var search by remember { mutableStateOf("") }

    if (detail != null) {
        DetailScreen(detail!!, onBack = { detail = null })
        return
    }

    Scaffold(
        containerColor = Ivory,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("YASH CIVITECH", fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("CONSULTANTS • V2.0", style = MaterialTheme.typography.labelSmall, color = Gold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepGreen),
                actions = {
                    IconButton(onClick = { tab = Tab.LEARN }) { Icon(Icons.Default.Search, "Search", tint = Color.White) }
                }
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, modifier = Modifier.navigationBarsPadding()) {
                navItem(tab, Tab.HOME, Icons.Default.Home, "Home") { tab = Tab.HOME }
                navItem(tab, Tab.LEARN, Icons.Default.MenuBook, "Learn") { tab = Tab.LEARN }
                navItem(tab, Tab.RESEARCH, Icons.Default.Science, "Research") { tab = Tab.RESEARCH }
                navItem(tab, Tab.FIELD, Icons.Default.Work, "Field") { tab = Tab.FIELD }
                navItem(tab, Tab.MORE, Icons.Default.CollectionsBookmark, "More") { tab = Tab.MORE }
            }
        }
    ) { padding ->
        when (tab) {
            Tab.HOME -> HomeScreen(content, online, padding, onOpen = { detail = it })
            Tab.LEARN -> LearnScreen(content, padding, search, onSearch = { search = it }, onOpen = { detail = it })
            Tab.RESEARCH -> ResearchScreen(content, padding, onOpen = { detail = it })
            Tab.FIELD -> FieldScreen(content, padding, onOpen = { detail = it })
            Tab.MORE -> MoreScreen(content, padding, onOpen = { detail = it })
        }
    }
}

@androidx.compose.runtime.Composable
private fun navItem(current: Tab, target: Tab, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    NavigationBarItem(selected = current == target, onClick = onClick, icon = { Icon(icon, label) }, label = { Text(label) })
}

@androidx.compose.runtime.Composable
private fun HomeScreen(content: Content, online: Boolean, padding: androidx.compose.foundation.layout.PaddingValues, onOpen: (Detail) -> Unit) {
    LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = DeepGreen), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Text("THE CIVIL ENGINEERING UNIVERSE", color = Gold, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Learn. Build. Research. Manage.", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("A single hub for civil engineering knowledge, site practice, technology, research, careers and project tools.", color = Ivory)
                    Spacer(Modifier.height(12.dp))
                    Text(if (online) "● LIVE CONTENT CONNECTED" else "● OFFLINE CORE LIBRARY READY", color = Gold, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            SectionTitle("Explore the sector", "24 engineering domains")
        }
        items(content.categories.take(8)) { c -> CategoryCard(c) { onOpen(Detail(DetailType.CATEGORY, c.name, "Civil Engineering Domain", c.description)) } }
        item {
            Spacer(Modifier.height(12.dp))
            SectionTitle("Research pulse", "Trending topics")
        }
        items(content.research.take(4)) { r -> ResearchCard(r) { onOpen(Detail(DetailType.RESEARCH, r.title, r.tag, r.summary, r.url)) } }
        item { Spacer(Modifier.height(90.dp)) }
    }
}

@androidx.compose.runtime.Composable
private fun LearnScreen(content: Content, padding: androidx.compose.foundation.layout.PaddingValues, search: String, onSearch: (String) -> Unit, onOpen: (Detail) -> Unit) {
    val filtered = content.categories.filter { it.name.contains(search, true) || it.description.contains(search, true) }
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) }, label = { Text("Search civil engineering") })
        Spacer(Modifier.height(14.dp))
        Text("Knowledge Library", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
        Text("Structural → geotech → infrastructure → digital → careers", color = Color.Gray)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { c -> CategoryCard(c) { onOpen(Detail(DetailType.CATEGORY, c.name, "Knowledge Library", c.description)) } }
            item { Spacer(Modifier.height(70.dp)) }
        }
    }
}

@androidx.compose.runtime.Composable
private fun ResearchScreen(content: Content, padding: androidx.compose.foundation.layout.PaddingValues, onOpen: (Detail) -> Unit) {
    LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)); Text("Research & Trends", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Text("Fresh themes from the civil-engineering technology landscape", color = Color.Gray); Spacer(Modifier.height(12.dp)) }
        items(content.research) { r -> ResearchCard(r) { onOpen(Detail(DetailType.RESEARCH, r.title, r.tag, "${r.summary}\n\nSource: ${r.source}", r.url)) } }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@androidx.compose.runtime.Composable
private fun FieldScreen(content: Content, padding: androidx.compose.foundation.layout.PaddingValues, onOpen: (Detail) -> Unit) {
    LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)); Text("Field & Lab", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Text("Practical test cards, purpose and workflow", color = Color.Gray); Spacer(Modifier.height(12.dp)) }
        items(content.practicals) { p -> PracticalCard(p) { onOpen(Detail(DetailType.PRACTICAL, p.title, p.group, "Purpose: ${p.purpose}\n\nProcedure: ${p.steps}")) } }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@androidx.compose.runtime.Composable
private fun MoreScreen(content: Content, padding: androidx.compose.foundation.layout.PaddingValues, onOpen: (Detail) -> Unit) {
    LazyColumn(contentPadding = padding, modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item { Spacer(Modifier.height(16.dp)); Text("Professional Toolkit", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.height(14.dp)) }
        item { SectionTitle("Engineering tools", "Quick formulas") }
        items(content.tools) { t -> ToolCard(t) { onOpen(Detail(DetailType.TOOL, t.title, "Calculator / Formula", "${t.formula}\n\n${t.note}")) } }
        item { Spacer(Modifier.height(12.dp)); SectionTitle("Site templates", "Ready-to-customize formats") }
        items(content.templates) { t -> ToolCard( Tool(t.title, "Template", t.fields)) { onOpen(Detail(DetailType.TEMPLATE, t.title, "Template", t.fields.replace(" | ", "\n"))) } }
        item { Spacer(Modifier.height(12.dp)); SectionTitle("Media Hub", "Videos & learning") }
        items(content.media) { m -> MediaCard(m) }
        item { Spacer(Modifier.height(90.dp)) }
    }
}

@androidx.compose.runtime.Composable
private fun SectionTitle(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge); Text(subtitle, style = MaterialTheme.typography.labelMedium, color = Color.Gray) }
        Divider(Modifier.width(45.dp).padding(bottom = 6.dp), color = Gold, thickness = 3.dp)
    }
}

@androidx.compose.runtime.Composable
private fun CategoryCard(c: Category, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(c.icon, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.size(44.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(c.name, fontWeight = FontWeight.Bold); Text(c.description, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@androidx.compose.runtime.Composable
private fun ResearchCard(r: Research, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = SoftGreen), modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(r.tag, color = DeepGreen, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(5.dp)); Text(r.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium); Spacer(Modifier.height(5.dp)); Text(r.summary, color = Color.DarkGray, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
    }
}

@androidx.compose.runtime.Composable
private fun PracticalCard(p: Practical, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Science, null, tint = DeepGreen, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(12.dp)); Column { Text(p.title, fontWeight = FontWeight.Bold); Text(p.group, color = Gold, style = MaterialTheme.typography.labelMedium); Text(p.purpose, color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@androidx.compose.runtime.Composable
private fun ToolCard(t: Tool, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (t.formula == "Template") Icons.Default.CollectionsBookmark else Icons.Default.Calculate, null, tint = DeepGreen, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(12.dp)); Column { Text(t.title, fontWeight = FontWeight.Bold); Text(t.formula, color = DeepGreen, style = MaterialTheme.typography.bodyMedium); Text(t.note, color = Color.Gray, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis) }
        }
    }
}

@androidx.compose.runtime.Composable
private fun MediaCard(m: Media) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Card(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(m.url))) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PlayCircleOutline, null, tint = DeepGreen, modifier = Modifier.size(36.dp)); Spacer(Modifier.width(12.dp)); Column { Text(m.title, fontWeight = FontWeight.Bold); Text("Open learning video", color = Color.Gray, style = MaterialTheme.typography.bodySmall) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.compose.runtime.Composable
private fun DetailScreen(detail: Detail, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text(detail.title, maxLines = 1, overflow = TextOverflow.Ellipsis) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepGreen, titleContentColor = Color.White, navigationIconContentColor = Color.White)) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp).verticalScroll(rememberScrollState())) {
            Text(detail.subtitle, color = Gold, fontWeight = FontWeight.Bold); Spacer(Modifier.height(14.dp)); Text(detail.body, style = MaterialTheme.typography.bodyLarge); Spacer(Modifier.height(22.dp))
            if (detail.url != null) { Card(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(detail.url))) }, colors = CardDefaults.cardColors(containerColor = DeepGreen), modifier = Modifier.fillMaxWidth()) { Text("Open source / reference", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(18.dp)) } }
        }
    }
}

private fun parseContent(text: String): Content {
    val root = JSONObject(text)
    val categories = buildList { val a = root.getJSONArray("categories"); for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(Category(o.getString("name"),o.getString("icon"),o.getString("description"))) } }
    val research = buildList { val a=root.getJSONArray("research"); for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Research(o.getString("title"),o.getString("tag"),o.getString("summary"),o.getString("source"),o.getString("url")))} }
    val practicals = buildList { val a=root.getJSONArray("practicals"); for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Practical(o.getString("title"),o.getString("group"),o.getString("purpose"),o.getString("steps")))} }
    val tools = buildList { val a=root.getJSONArray("tools"); for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Tool(o.getString("title"),o.getString("formula"),o.getString("note")))} }
    val templates = buildList { val a=root.getJSONArray("templates"); for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Template(o.getString("title"),o.getString("fields")))} }
    val media = buildList { val a=root.getJSONArray("media"); for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Media(o.getString("title"),o.getString("type"),o.getString("url")))} }
    return Content(categories,research,practicals,tools,templates,media)
}

private fun sampleContent() = Content(
    categories = listOf(
        Category("Structural Engineering","🏗","Analysis, design, detailing, assessment and rehabilitation of concrete, steel, masonry and composite structures."),
        Category("Geotechnical Engineering","⛰","Soil mechanics, site investigation, foundations, retaining systems, slopes and ground improvement."),
        Category("Highway & Pavement","🛣","Highway alignment, geometric design, flexible and rigid pavements, materials, construction and maintenance."),
        Category("Bridge Engineering","🌉","Bridge types, foundations, piers, bearings, expansion joints, inspection and rehabilitation."),
        Category("Railway & Metro","🚇","Railway track, metro viaducts, stations, tunnels, construction planning and systems interfaces."),
        Category("Water Resources & Hydraulics","💧","Hydrology, hydraulics, canals, dams, drainage, flood management and water infrastructure."),
        Category("Environmental Engineering","🌱","Water treatment, wastewater, solid waste, air quality, environmental monitoring and sustainability."),
        Category("Construction Management","📋","Planning, scheduling, productivity, contracts, procurement, QA/QC, cost and project controls."),
        Category("Surveying & Geomatics","📐","Total station, GNSS, GIS, remote sensing, LiDAR, drone mapping and digital terrain models."),
        Category("Concrete & Materials","🧱","Cement, concrete, aggregates, admixtures, durability, testing and advanced construction materials."),
        Category("BIM / VDC / Digital Twins","🖥","BIM coordination, 4D/5D planning, asset information, digital twins and connected infrastructure."),
        Category("AI & Data in Civil Engineering","🤖","Machine learning, computer vision, predictive maintenance, data analytics and AI-assisted workflows."),
        Category("Robotics & Automation","🦾","Autonomous equipment, robotic inspection, automated construction and site productivity technologies."),
        Category("3D Printing & Additive Construction","🖨","3D concrete printing, automated deposition, materials, workflows and emerging applications."),
        Category("Sustainable & Low-Carbon Construction","♻️","Low-carbon cement, recycled materials, embodied carbon, circular construction and lifecycle thinking."),
        Category("Climate-Resilient Infrastructure","🌍","Flood, heat, landslide, cyclone, earthquake and climate adaptation for infrastructure assets."),
        Category("Tunnel & Underground Engineering","🚇","Tunnelling methods, ground support, excavation, monitoring, ventilation and underground structures."),
        Category("Airport Engineering","✈️","Runways, taxiways, pavements, drainage, terminals, airside planning and airport infrastructure."),
        Category("Coastal & Marine Engineering","🌊","Ports, harbours, breakwaters, coastal protection, erosion and marine infrastructure."),
        Category("Dam Engineering","🏞","Concrete and earth dams, spillways, seepage, instrumentation, safety and rehabilitation."),
        Category("Quantity Surveying & Cost Engineering","💰","BOQ, estimation, rate analysis, measurement, valuation, cost control and commercial management."),
        Category("Contracts, Claims & Project Controls","⚖️","Tendering, contract administration, variations, claims, EOT, risk, earned value and reporting."),
        Category("HSE & Construction Safety","🦺","Risk assessment, permits, excavation safety, lifting, work at height, PPE and site inspections."),
        Category("Careers, Exams & Professional Skills","🎓","Civil engineering careers, interviews, competitive exams, software skills, certifications and portfolios.")
    ),
    research = listOf(
        Research("AI + Digital Twins for Infrastructure","TRENDING 2026","AI, sensing and digital twins are increasingly being combined for infrastructure monitoring, management and predictive maintenance.","ASCE / civil infrastructure research","https://www.asce.org/"),
        Research("Smart Sensing & Infrastructure Health Monitoring","RESEARCH","Sensor networks, AI and data analytics are being studied for condition assessment and asset management.","ASCE Engineering Mechanics Institute","https://www.asce.org/engineering-mechanics-institute"),
        Research("Low-Carbon Concrete & Cement","NET ZERO","Research is accelerating around lower-carbon binders, alternative materials and lifecycle carbon reduction.","NRC Construction Research Centre","https://nrc.canada.ca/"),
        Research("Robotics & Autonomous Construction","EMERGING","Robotics and automated equipment are emerging across repetitive construction and inspection tasks.","Civil engineering technology research","https://www.asce.org/"),
        Research("3D Concrete Printing","EMERGING","Additive construction is developing new approaches to automated placement, formwork reduction and construction productivity.","ASCE conference research","https://www.asce.org/"),
        Research("Climate-Resilient Infrastructure","RESILIENCE","Infrastructure design and asset management increasingly address extreme weather, hazards and long-term resilience.","NRC Construction Research Centre","https://nrc.canada.ca/"),
        Research("BIM, 4D/5D and Connected Project Delivery","DIGITAL","BIM-based information management is expanding toward schedule, cost, asset and lifecycle integration.","ASCE / infrastructure practice","https://www.asce.org/")
    ),
    practicals = listOf(
        Practical("Concrete Slump Test","Concrete","Measures fresh concrete workability","Prepare cone and base; fill in layers; rod each layer; lift vertically; measure slump."),
        Practical("Concrete Cube Compressive Strength","Concrete","Determines compressive strength of hardened concrete","Prepare representative samples; compact in moulds; cure; test at specified age; record failure load and strength."),
        Practical("Rebound Hammer Test","NDT","Indicative surface hardness and uniformity","Prepare test area; position hammer correctly; take multiple readings; reject abnormal readings; interpret with applicable guidance."),
        Practical("Ultrasonic Pulse Velocity","NDT","Assesses concrete quality and continuity","Place transducers with suitable coupling; measure pulse travel time; calculate velocity; assess uniformity and anomalies."),
        Practical("Proctor Compaction Test","Soil","Determines moisture-density relationship","Compact soil at controlled moisture contents; determine bulk and dry density; plot curve and identify OMC and MDD."),
        Practical("California Bearing Ratio (CBR)","Soil / Pavement","Evaluates subgrade bearing performance","Prepare specimen at required condition; compact; surcharge and soak if specified; penetrate at controlled rate; calculate CBR."),
        Practical("Grain Size Analysis","Soil","Determines particle-size distribution","Perform sieve analysis for coarse fraction and hydrometer analysis where applicable; calculate percentages passing."),
        Practical("Atterberg Limits","Soil","Characterizes fine-grained soil consistency","Determine liquid limit and plastic limit using the applicable laboratory procedure; calculate plasticity index."),
        Practical("Bitumen Penetration Test","Bitumen","Measures consistency of bitumen","Condition sample; place penetration apparatus; apply standard needle load/time; record penetration value."),
        Practical("Field Density Test","Field","Checks in-situ compaction","Prepare test location; determine in-situ volume/mass by applicable method; calculate field dry density and degree of compaction.")
    ),
    tools = listOf(
        Tool("Concrete Volume","V = L × W × T","Use consistent units; add appropriate allowances for the actual construction quantity."),
        Tool("Steel Unit Weight","W ≈ d² / 162 kg/m","For reinforcement bar diameter d in mm; educational field-estimation formula."),
        Tool("Manning Flow","Q = (1/n) A R^(2/3) S^(1/2)","For open-channel flow; confirm assumptions and units before engineering use."),
        Tool("Simple Slope Gradient","Gradient = Rise / Run","Convert to percentage by multiplying by 100; use survey control for actual works."),
        Tool("Earthwork Volume","V ≈ L × average cross-sectional area","Use appropriate end-area/prismoidal methods for actual quantity measurement."),
        Tool("Concrete Rebar Spacing","Number ≈ clear length / spacing + 1","Check cover, edge distances, laps and project drawings before placement.")
    ),
    templates = listOf(
        Template("Daily Progress Report","Project | Date | Location | Weather | Manpower | Equipment | Work Executed | Quantities | Safety | QA/QC | Constraints | Photos | Next-Day Plan"),
        Template("Method Statement","Activity | Scope | References | Materials | Plant | Manpower | Sequence | Inspection | QA/QC | HSE | Environmental Controls | Acceptance Criteria"),
        Template("Inspection & Test Plan (ITP)","Activity | Inspection Point | Test | Acceptance Criteria | Frequency | Responsibility | Record | Hold/Witness Point"),
        Template("Concrete Pour Checklist","Pour Location | Drawing | Mix | Batch Tickets | Slump | Temperature | Reinforcement | Cover | Formwork | Embedded Items | Vibrator | Curing | Cube Samples | Approvals"),
        Template("Rebar Inspection","Drawing | Member | Bar Dia | Spacing | Quantity | Lap | Anchorage | Cover | Chairs | Couplers | Cleanliness | Approval"),
        Template("RFI / WIR","Project | RFI/WIR No. | Location | Description | Drawing/Specification | Requested Inspection | Date | Contractor | Consultant Response"),
        Template("Safety Inspection","Location | Activity | Hazard | Risk | Control | PPE | Housekeeping | Access | Lifting | Work at Height | Corrective Action | Responsible Person"),
        Template("BOQ Measurement Sheet","Item | Description | Location | Drawing | Unit | Dimensions | Quantity | Rate | Amount | Remarks")
    ),
    media = listOf(
        Media("BIM and Digital Construction","Video","https://www.youtube.com/results?search_query=BIM+digital+construction"),
        Media("Concrete Technology & Testing","Video","https://www.youtube.com/results?search_query=concrete+technology+lab+tests+civil+engineering"),
        Media("Surveying, GNSS and GIS","Video","https://www.youtube.com/results?search_query=surveying+GNSS+GIS+civil+engineering"),
        Media("Construction Safety","Video","https://www.youtube.com/results?search_query=construction+site+safety+civil+engineering"),
        Media("AI in Construction","Video","https://www.youtube.com/results?search_query=AI+in+construction+civil+engineering")
    )
)
