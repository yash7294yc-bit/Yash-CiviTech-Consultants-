package com.yashcivitech.consultants.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepGreen = Color(0xFF06261F)
val DeepGreen2 = Color(0xFF0C3329)
val Gold = Color(0xFFD9B86C)
val Ivory = Color(0xFFF7F1E4)
val Ink = Color(0xFF17231F)
val Muted = Color(0xFF68736E)

private val Scheme = lightColorScheme(primary = DeepGreen, onPrimary = Ivory, secondary = Gold, onSecondary = DeepGreen, background = Ivory, surface = Color(0xFFFFFCF5), onBackground = Ink, onSurface = Ink)

@Composable fun YashCiviTechTheme(content: @Composable () -> Unit) { MaterialTheme(colorScheme = Scheme, typography = Typography(), content = content) }
