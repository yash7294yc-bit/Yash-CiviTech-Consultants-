package com.yashcivitech.consultants

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.yashcivitech.consultants.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { YashCiviTechTheme { App() } } }
}

data class Feature(val title:String, val icon:@Composable ()->Unit, val body:String)
private val features = listOf(
    Feature("Knowledge Hub", { Icon(Icons.Default.MenuBook, null) }, "Civil engineering fundamentals, methods, standards and field knowledge."),
    Feature("Career Opportunities", { Icon(Icons.Default.Work, null) }, "Jobs, internships, roles, skills and career guidance."),
    Feature("Construction Methodology", { Icon(Icons.Default.Construction, null) }, "Step-by-step execution methods, sequencing and quality practices."),
    Feature("Latest Technology", { Icon(Icons.Default.Memory, null) }, "Modern construction technology, digital tools and innovation."),
    Feature("IS Codes", { Icon(Icons.Default.Description, null) }, "Quick references to important Indian Standards and code topics."),
    Feature("Field & Lab Tests", { Icon(Icons.Default.Science, null) }, "Practical tests, procedures, observations and engineering calculations."),
    Feature("Infrastructure Projects", { Icon(Icons.Default.Domain, null) }, "Bridges, roads, metro, buildings and major infrastructure case studies."),
    Feature("News & Updates", { Icon(Icons.Default.Newspaper, null) }, "Industry developments, updates and useful engineering resources."),
    Feature("Community", { Icon(Icons.Default.Groups, null) }, "Connect, discuss and learn with fellow civil engineering professionals."),
)

@Composable fun App() {
    var welcomed by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Feature?>(null) }
    if (!welcomed) WelcomeScreen { welcomed = true } else if (selected != null) DetailScreen(selected!!) { selected = null } else {
        Scaffold(bottomBar = { BottomNav(tab) { tab = it } }) { p ->
            when(tab) { 0 -> HomeScreen { selected = it }; 1 -> ExploreScreen { selected = it }; 2 -> SavedScreen(); else -> ProfileScreen() }
        }
    }
}

@Composable private fun WelcomeScreen(onStart:()->Unit) {
    Column(Modifier.fillMaxSize().background(DeepGreen).padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.weight(1f)); Text("Y", color=Gold, fontSize=68.sp, fontWeight=FontWeight.Light); Text("Yash CiviTech", color=Ivory, fontSize=31.sp, fontWeight=FontWeight.SemiBold); Text("Consultants", color=Gold, fontSize=19.sp, letterSpacing=2.sp); Spacer(Modifier.height(12.dp)); Text("LEARN  •  GROW  •  BUILD", color=Gold, fontSize=11.sp, letterSpacing=3.sp); Spacer(Modifier.height(28.dp)); Text("Your complete platform for\ncivil engineering knowledge,\ncareer & construction excellence", color=Ivory, fontSize=16.sp, textAlign=TextAlign.Center, lineHeight=24.sp); Spacer(Modifier.weight(1f)); Button(onClick=onStart, modifier=Modifier.fillMaxWidth().height(58.dp), colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=DeepGreen), shape=RoundedCornerShape(30.dp)) { Text("Get Started", fontWeight=FontWeight.Bold) }; Spacer(Modifier.height(22.dp))
    }
}

@Composable private fun Header() { Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=14.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Menu, null); Spacer(Modifier.weight(1f)); Text("Yash CiviTech", fontWeight=FontWeight.Bold, fontSize=18.sp); Text(" Consultants", color=Gold, fontSize=12.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.NotificationsNone, null) } }

@Composable private fun HomeScreen(onFeature:(Feature)->Unit) {
    LazyColumn(contentPadding=PaddingValues(bottom=90.dp)) { item { Header(); Hero(); Spacer(Modifier.height(14.dp)); Text("Explore", modifier=Modifier.padding(horizontal=20.dp), fontWeight=FontWeight.Bold, fontSize=22.sp); Spacer(Modifier.height(10.dp)) }; item { FeatureGrid(onFeature) }; item { Featured() } }
}

@Composable private fun Hero() { Card(Modifier.padding(horizontal=16.dp).fillMaxWidth(), shape=RoundedCornerShape(24.dp), colors=CardDefaults.cardColors(containerColor=DeepGreen)) { Column(Modifier.padding(22.dp)) { Text("BUILDING A BETTER TOMORROW", color=Gold, fontSize=10.sp, letterSpacing=2.sp); Spacer(Modifier.height(8.dp)); Text("Knowledge Today,\nStronger Infrastructure\nTomorrow", color=Ivory, fontSize=27.sp, fontWeight=FontWeight.Bold, lineHeight=31.sp); Spacer(Modifier.height(18.dp)); Button(onClick={}, colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=DeepGreen), shape=RoundedCornerShape(22.dp)) { Text("Explore Resources  →") } } } }

@Composable private fun FeatureGrid(onFeature:(Feature)->Unit) { Column(Modifier.padding(horizontal=16.dp)) { features.chunked(3).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) { row.forEach { f -> Card(Modifier.weight(1f).padding(vertical=4.dp).height(104.dp).clickable{onFeature(f)}, shape=RoundedCornerShape(16.dp)) { Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) { CompositionLocalProvider(LocalContentColor provides DeepGreen) { f.icon() }; Spacer(Modifier.height(7.dp)); Text(f.title, fontSize=11.sp, fontWeight=FontWeight.Medium, textAlign=TextAlign.Center, lineHeight=13.sp) } } } } } } }

@Composable private fun Featured() { Column(Modifier.padding(20.dp)) { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Featured Insights", fontWeight=FontWeight.Bold, fontSize=18.sp); Text("View all →", color=DeepGreen, fontSize=12.sp) }; Spacer(Modifier.height(10.dp)); Card(shape=RoundedCornerShape(16.dp)) { Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.Description, null, tint=Gold); Spacer(Modifier.width(12.dp)); Column { Text("Latest IS Code Update", fontWeight=FontWeight.SemiBold); Text("Standards, changes and practical implications", color=Muted, fontSize=12.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } } } }

@Composable private fun ExploreScreen(onFeature:(Feature)->Unit) { LazyColumn(contentPadding=PaddingValues(bottom=90.dp)) { item { Header(); Text("Explore Resources", Modifier.padding(horizontal=20.dp), fontSize=28.sp, fontWeight=FontWeight.Bold); Text("Everything you need to learn, work and grow.", Modifier.padding(20.dp,6.dp), color=Muted) }; items(features) { f -> ListFeature(f){onFeature(f)} } } }
@Composable private fun ListFeature(f:Feature,onClick:()->Unit) { Card(Modifier.padding(horizontal=16.dp, vertical=5.dp).fillMaxWidth().clickable{onClick()}, shape=RoundedCornerShape(16.dp)) { Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) { CompositionLocalProvider(LocalContentColor provides DeepGreen) { f.icon() }; Spacer(Modifier.width(15.dp)); Column(Modifier.weight(1f)){Text(f.title,fontWeight=FontWeight.SemiBold);Text(f.body,color=Muted,fontSize=12.sp)};Icon(Icons.Default.ChevronRight,null) } } }
@Composable private fun SavedScreen(){ EmptyState("Saved Resources","Bookmark articles, tests and career opportunities to find them here.",Icons.Default.BookmarkBorder) }
@Composable private fun ProfileScreen(){ EmptyState("Your Profile","Your learning progress, saved resources and preferences will appear here.",Icons.Default.PersonOutline) }
@Composable private fun EmptyState(title:String,body:String,icon:androidx.compose.ui.graphics.vector.ImageVector){ Column(Modifier.fillMaxSize().padding(32.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(icon,null,tint=Gold,modifier=Modifier.size(64.dp));Spacer(Modifier.height(18.dp));Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text(body,color=Muted,textAlign=TextAlign.Center);Spacer(Modifier.height(90.dp))} }

@Composable private fun DetailScreen(f:Feature,onBack:()->Unit){ Column(Modifier.fillMaxSize().background(Ivory)){ Row(Modifier.fillMaxWidth().background(DeepGreen).padding(14.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null,tint=Ivory)};Text(f.title,color=Ivory,fontSize=20.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Icon(Icons.Default.Search,null,tint=Ivory)}; Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)){Text(if(f.title=="Construction Methodology")"RCC Building Construction – Step by Step Process" else f.title,fontSize=28.sp,fontWeight=FontWeight.Bold,color=Ink);Spacer(Modifier.height(10.dp));Text(f.body,fontSize=16.sp,color=Muted,lineHeight=24.sp);Spacer(Modifier.height(22.dp));Section("01", "Site Preparation & Planning");Section("02", "Materials, Methods & Execution");Section("03", "Quality Control & Safety");Section("04", "Field Notes & Practical Checks");Spacer(Modifier.height(20.dp));Button(onClick={},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=DeepGreen),shape=RoundedCornerShape(22.dp)){Icon(Icons.Default.BookmarkBorder,null);Spacer(Modifier.width(8.dp));Text("Save for Later")};Spacer(Modifier.height(30.dp))}} }
@Composable private fun Section(n:String,t:String){Card(Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text(n,color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.width(16.dp));Text(t,Modifier.weight(1f),fontWeight=FontWeight.Medium);Icon(Icons.Default.ChevronRight,null)}}}
@Composable private fun BottomNav(selected:Int,onSelect:(Int)->Unit){NavigationBar(containerColor=Color.White){listOf("Home" to Icons.Default.Home,"Explore" to Icons.Default.Search,"Saved" to Icons.Default.BookmarkBorder,"Profile" to Icons.Default.PersonOutline).forEachIndexed{index,(label,icon)->NavigationBarItem(selected=selected==index,onClick={onSelect(index)},icon={Icon(icon,null)},label={Text(label,fontSize=10.sp)})}}}
