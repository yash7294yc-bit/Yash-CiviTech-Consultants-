package com.yashcivitech.consultants

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val DeepGreen = Color(0xFF06261F)
private val Gold = Color(0xFFD9B86C)
private val Ivory = Color(0xFFF7F1E4)
private val SoftGreen = Color(0xFFE8F0EC)
private const val REMOTE_CONTENT = "https://raw.githubusercontent.com/yash7294yc-bit/Yash-CiviTech-Consultants/main/content.json"

data class Category(val name:String,val icon:String,val description:String,val overview:String,val topics:String,val workflow:String,val standards:String,val sourceUrl:String)
data class Research(val title:String,val tag:String,val summary:String,val source:String,val url:String)
data class Practical(val title:String,val group:String,val objective:String,val standards:String,val equipment:String,val procedure:String,val calculation:String,val interpretation:String,val precautions:String,val sourceUrl:String)
data class Standard(val code:String,val title:String,val status:String,val scope:String,val notes:String,val url:String)
data class Tool(val title:String,val formula:String,val note:String,val details:String)
data class Template(val title:String,val fields:List<String>)
data class Media(val title:String,val type:String,val url:String)
data class Content(val categories:List<Category>,val research:List<Research>,val practicals:List<Practical>,val standards:List<Standard>,val tools:List<Tool>,val templates:List<Template>,val media:List<Media>)

enum class Tab { HOME, LEARN, RESEARCH, FIELD, MORE }

data class Detail(val title:String,val subtitle:String,val body:String,val url:String?=null)

class MainActivity : ComponentActivity() {
    private var contentState = mutableStateOf(emptyContent())
    private var onlineState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        contentState.value = runCatching { assets.open("content.json").bufferedReader().use { parseContent(it.readText()) } }.getOrElse { emptyContent() }
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary=DeepGreen,secondary=Gold,background=Ivory,surface=Color.White,onPrimary=Color.White,onBackground=DeepGreen,onSurface=DeepGreen)) {
                AppRoot(contentState.value, onlineState.value)
            }
        }
        lifecycleScope.launch {
            val remote = loadRemoteContent()
            if (remote != null) { contentState.value=remote; onlineState.value=true }
        }
    }

    private suspend fun loadRemoteContent(): Content? = withContext(Dispatchers.IO) {
        runCatching {
            val c = URL(REMOTE_CONTENT).openConnection() as HttpURLConnection
            c.connectTimeout=8000; c.readTimeout=8000; c.requestMethod="GET"
            c.inputStream.bufferedReader().use { parseContent(it.readText()) }.also { c.disconnect() }
        }.getOrNull()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun AppRoot(content:Content, online:Boolean) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var detail by remember { mutableStateOf<Detail?>(null) }
    var search by remember { mutableStateOf("") }
    if (detail != null) { DetailScreen(detail!!){detail=null}; return }
    Scaffold(containerColor=Ivory,topBar={TopAppBar(title={Column{Text("YASH CIVITECH",fontWeight=FontWeight.ExtraBold,color=Color.White);Text("CONSULTANTS • V3.0",style=MaterialTheme.typography.labelSmall,color=Gold)}},colors=TopAppBarDefaults.topAppBarColors(containerColor=DeepGreen),actions={IconButton(onClick={tab=Tab.LEARN}){Icon(Icons.Default.Search,"Search",tint=Color.White)}})},bottomBar={NavigationBar(containerColor=Color.White,modifier=Modifier.navigationBarsPadding()){
        NavigationBarItem(tab==Tab.HOME,{tab=Tab.HOME},{Icon(Icons.Default.Home,"Home")},{Text("Home")})
        NavigationBarItem(tab==Tab.LEARN,{tab=Tab.LEARN},{Icon(Icons.Default.MenuBook,"Learn")},{Text("Learn")})
        NavigationBarItem(tab==Tab.RESEARCH,{tab=Tab.RESEARCH},{Icon(Icons.Default.Science,"Research")},{Text("Research")})
        NavigationBarItem(tab==Tab.FIELD,{tab=Tab.FIELD},{Icon(Icons.Default.Work,"Field")},{Text("Field")})
        NavigationBarItem(tab==Tab.MORE,{tab=Tab.MORE},{Icon(Icons.Default.CollectionsBookmark,"More")},{Text("More")})
    }}){padding->when(tab){Tab.HOME->HomeScreen(content,online,padding){detail=it};Tab.LEARN->LearnScreen(content,padding,search,{search=it}){detail=it};Tab.RESEARCH->ResearchScreen(content,padding){detail=it};Tab.FIELD->FieldScreen(content,padding){detail=it};Tab.MORE->MoreScreen(content,padding){detail=it}}}
}

@Composable private fun HomeScreen(c:Content,online:Boolean,p:PaddingValues,open:(Detail)->Unit){
    Column(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp).verticalScroll(rememberScrollState())){
        Spacer(Modifier.height(18.dp)); Card(colors=CardDefaults.cardColors(containerColor=DeepGreen),shape=RoundedCornerShape(24.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(22.dp)){Text("CIVIL ENGINEERING KNOWLEDGE BASE",color=Gold,fontWeight=FontWeight.Bold);Text("Learn. Build. Research. Verify.",color=Color.White,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(8.dp));Text("Detailed core knowledge, BIS/IS references, field and laboratory practicals, tools, templates and research.",color=Ivory);Spacer(Modifier.height(12.dp));Text(if(online)"● LIVE LIBRARY CONNECTED" else "● OFFLINE LIBRARY READY",color=Gold,fontWeight=FontWeight.Bold)}}
        Spacer(Modifier.height(18.dp));SectionTitle("Core knowledge","24 civil-engineering domains");Spacer(Modifier.height(10.dp));c.categories.take(8).forEach{cat->CategoryCard(cat){open(categoryDetail(cat))};Spacer(Modifier.height(10.dp))}
        Spacer(Modifier.height(8.dp));SectionTitle("Latest research","Evidence-linked learning");Spacer(Modifier.height(10.dp));c.research.take(4).forEach{r->ResearchCard(r){open(Detail(r.title,r.tag,"${r.summary}\n\nSource: ${r.source}",r.url))};Spacer(Modifier.height(10.dp))}
        Spacer(Modifier.height(8.dp));SectionTitle("Standards index","BIS / IS references");Spacer(Modifier.height(10.dp));c.standards.take(4).forEach{s->StandardCard(s){open(standardDetail(s))};Spacer(Modifier.height(10.dp))};Spacer(Modifier.height(80.dp))
    }
}

@Composable private fun LearnScreen(c:Content,p:PaddingValues,search:String,onSearch:(String)->Unit,open:(Detail)->Unit){val f=c.categories.filter{it.name.contains(search,true)||it.description.contains(search,true)||it.topics.contains(search,true)};Column(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp).verticalScroll(rememberScrollState())){Spacer(Modifier.height(14.dp));OutlinedTextField(search,onSearch,Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},label={Text("Search civil engineering")});Spacer(Modifier.height(14.dp));Text("Knowledge Library",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold);Text("Open a domain for fundamentals, workflow, standards guidance and applications",color=Color.Gray);Spacer(Modifier.height(10.dp));f.forEach{cat->CategoryCard(cat){open(categoryDetail(cat))};Spacer(Modifier.height(10.dp))};Spacer(Modifier.height(70.dp))}}

@Composable private fun ResearchScreen(c:Content,p:PaddingValues,open:(Detail)->Unit){Column(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp).verticalScroll(rememberScrollState())){Spacer(Modifier.height(16.dp));Text("Research & Trends",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold);Text("Research summaries with source links",color=Color.Gray);Spacer(Modifier.height(12.dp));c.research.forEach{r->ResearchCard(r){open(Detail(r.title,r.tag,"${r.summary}\n\nSource: ${r.source}",r.url))};Spacer(Modifier.height(10.dp))};Spacer(Modifier.height(80.dp))}}

@Composable private fun FieldScreen(c:Content,p:PaddingValues,open:(Detail)->Unit){Column(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp).verticalScroll(rememberScrollState())){Spacer(Modifier.height(16.dp));Text("Field & Laboratory",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold);Text("Purpose → standard → equipment → procedure → calculation → interpretation → precautions",color=Color.Gray);Spacer(Modifier.height(12.dp));c.practicals.forEach{pr->PracticalCard(pr){open(practicalDetail(pr))};Spacer(Modifier.height(10.dp))};Spacer(Modifier.height(80.dp))}}

@Composable private fun MoreScreen(c:Content,p:PaddingValues,open:(Detail)->Unit){Column(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp).verticalScroll(rememberScrollState())){Spacer(Modifier.height(16.dp));Text("Professional Toolkit",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.ExtraBold);Spacer(Modifier.height(14.dp));SectionTitle("BIS / IS Standards","24 indexed references");Spacer(Modifier.height(10.dp));c.standards.forEach{s->StandardCard(s){open(standardDetail(s))};Spacer(Modifier.height(10.dp))};SectionTitle("Engineering tools","Educational formulas");Spacer(Modifier.height(10.dp));c.tools.forEach{t->ToolCard(t){open(Detail(t.title,"Formula / calculator","${t.formula}\n\n${t.note}\n\nDetails: ${t.details}"))};Spacer(Modifier.height(10.dp))};SectionTitle("Site templates","Ready-to-customize formats");Spacer(Modifier.height(10.dp));c.templates.forEach{t->ToolCard(Tool(t.title,"Template",t.fields.joinToString(" • "),"Field checklist")){open(Detail(t.title,"Template",t.fields.joinToString("\n• "))) };Spacer(Modifier.height(10.dp))};SectionTitle("Media Hub","External learning resources");Spacer(Modifier.height(10.dp));c.media.forEach{MediaCard(it);Spacer(Modifier.height(10.dp))};Spacer(Modifier.height(80.dp))}}

@Composable private fun SectionTitle(t:String,s:String){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.Bottom){Column(Modifier.weight(1f)){Text(t,fontWeight=FontWeight.ExtraBold,style=MaterialTheme.typography.titleLarge);Text(s,style=MaterialTheme.typography.labelMedium,color=Color.Gray)}Text("◆",color=Gold)}}

@Composable private fun CategoryCard(c:Category,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(c.icon,style=MaterialTheme.typography.headlineSmall,modifier=Modifier.size(44.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(c.name,fontWeight=FontWeight.Bold);Text(c.description,maxLines=3,overflow=TextOverflow.Ellipsis,color=Color.Gray,style=MaterialTheme.typography.bodySmall)}}}}

@Composable private fun ResearchCard(r:Research,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=SoftGreen)){Column(Modifier.padding(16.dp)){Text(r.tag,color=DeepGreen,style=MaterialTheme.typography.labelSmall,fontWeight=FontWeight.ExtraBold);Text(r.title,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(5.dp));Text(r.summary,color=Color.DarkGray,maxLines=4,overflow=TextOverflow.Ellipsis)}}}

@Composable private fun PracticalCard(p:Practical,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Science,null,tint=DeepGreen,modifier=Modifier.size(30.dp));Spacer(Modifier.width(12.dp));Column{Text(p.title,fontWeight=FontWeight.Bold);Text(p.group,color=Gold,style=MaterialTheme.typography.labelMedium);Text(p.objective,color=Color.Gray,style=MaterialTheme.typography.bodySmall,maxLines=3,overflow=TextOverflow.Ellipsis)}}}}

@Composable private fun StandardCard(s:Standard,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color.White)){Column(Modifier.padding(16.dp)){Text(s.code,color=DeepGreen,fontWeight=FontWeight.ExtraBold);Text(s.title,fontWeight=FontWeight.Bold);Text(s.status,color=Gold,style=MaterialTheme.typography.labelSmall);Text(s.scope,color=Color.Gray,style=MaterialTheme.typography.bodySmall,maxLines=3,overflow=TextOverflow.Ellipsis)}}}

@Composable private fun ToolCard(t:Tool,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(t.formula=="Template")Icons.Default.CollectionsBookmark else Icons.Default.Calculate,null,tint=DeepGreen,modifier=Modifier.size(30.dp));Spacer(Modifier.width(12.dp));Column{Text(t.title,fontWeight=FontWeight.Bold);Text(t.formula,color=DeepGreen);Text(t.note,color=Color.Gray,style=MaterialTheme.typography.bodySmall,maxLines=3,overflow=TextOverflow.Ellipsis)}}}}

@Composable private fun MediaCard(m:Media){val ctx=LocalContext.current;Card(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(m.url)))},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.PlayCircleOutline,null,tint=DeepGreen,modifier=Modifier.size(36.dp));Spacer(Modifier.width(12.dp));Text(m.title,fontWeight=FontWeight.Bold)}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun DetailScreen(d:Detail,back:()->Unit){val ctx=LocalContext.current;Scaffold(topBar={TopAppBar(title={Text(d.title,maxLines=1,overflow=TextOverflow.Ellipsis)},navigationIcon={IconButton(onClick=back){Icon(Icons.AutoMirrored.Filled.ArrowBack,"Back")}},colors=TopAppBarDefaults.topAppBarColors(containerColor=DeepGreen,titleContentColor=Color.White,navigationIconContentColor=Color.White))}){p->Column(Modifier.fillMaxSize().padding(p).padding(20.dp).verticalScroll(rememberScrollState())){Text(d.subtitle,color=Gold,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));Text(d.body,style=MaterialTheme.typography.bodyLarge);Spacer(Modifier.height(22.dp));if(d.url!=null){Button(onClick={ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(d.url)))},colors=ButtonDefaults.buttonColors(containerColor=DeepGreen),modifier=Modifier.fillMaxWidth()){Text("Open official/source reference",color=Color.White)}}}}}

private fun categoryDetail(c:Category)=Detail(c.name,"Core Civil Engineering Knowledge","${c.overview}\n\nKEY TOPICS\n${c.topics}\n\nENGINEERING WORKFLOW\n${c.workflow}\n\nSTANDARDS GUIDANCE\n${c.standards}",c.sourceUrl)
private fun practicalDetail(p:Practical)=Detail(p.title,p.group,"OBJECTIVE\n${p.objective}\n\nSTANDARD / REFERENCE\n${p.standards}\n\nEQUIPMENT\n${p.equipment}\n\nPROCEDURE\n${p.procedure}\n\nCALCULATION\n${p.calculation}\n\nINTERPRETATION\n${p.interpretation}\n\nPRECAUTIONS\n${p.precautions}",p.sourceUrl)
private fun standardDetail(s:Standard)=Detail(s.code,s.title,"STATUS\n${s.status}\n\nSCOPE\n${s.scope}\n\nAPP GUIDANCE\n${s.notes}\n\nThe app provides an original educational summary and reference metadata; it does not reproduce the copyrighted standard text.",s.url)

private fun emptyContent()=Content(emptyList(),emptyList(),emptyList(),emptyList(),emptyList(),emptyList(),emptyList())
private fun parseContent(text:String):Content{
    val r=JSONObject(text)
    val cats=buildList{val a=r.getJSONArray("categories");for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Category(o.getString("name"),o.getString("icon"),o.getString("description"),o.getString("overview"),o.getString("key_topics"),o.getString("engineering_workflow"),o.getString("standards_guidance"),o.getString("source_url")))}}
    val research=buildList{val a=r.getJSONArray("research");for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Research(o.getString("title"),o.getString("tag"),o.getString("summary"),o.getString("source"),o.getString("url")))}}
    val practicals=buildList{val a=r.getJSONArray("practicals");for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Practical(o.getString("title"),o.getString("group"),o.getString("objective"),o.getString("standards"),o.getString("equipment"),o.getString("procedure"),o.getString("calculation"),o.getString("interpretation"),o.getString("precautions"),o.getString("source_url")))}}
    val standards=buildList{val a=r.getJSONArray("standards");for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Standard(o.getString("code"),o.getString("title"),o.getString("status"),o.getString("scope"),o.getString("notes"),o.getString("url")))}}
    val tools=buildList{val a=r.getJSONArray("tools");for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Tool(o.getString("title"),o.getString("formula"),o.getString("note"),o.getString("details")))}}
    val templates=buildList{val a=r.getJSONArray("templates");for(i in 0 until a.length()){val o=a.getJSONObject(i);val fs=o.getJSONArray("fields");add(Template(o.getString("title"),buildList{for(j in 0 until fs.length())add(fs.getString(j))}))}}
    val media=buildList{val a=r.getJSONArray("media");for(i in 0 until a.length()){val o=a.getJSONObject(i);add(Media(o.getString("title"),o.getString("type"),o.getString("url")))}}
    return Content(cats,research,practicals,standards,tools,templates,media)
}
